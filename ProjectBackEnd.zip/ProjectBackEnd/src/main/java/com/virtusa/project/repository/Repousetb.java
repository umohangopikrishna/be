package com.virtusa.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.project.models.Usertb;

public interface Repousetb extends JpaRepository<Usertb,Integer> {

}
