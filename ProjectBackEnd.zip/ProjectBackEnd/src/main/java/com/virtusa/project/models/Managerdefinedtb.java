package com.virtusa.project.models;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Managerdefinedtb {
	@Id
	@GeneratedValue
	private int id;
	private int manager_id;
	private String occuation;
	private String  data;
	private int fund;
	
	
	
	public Managerdefinedtb() {
		super();
	}
	
	public Managerdefinedtb(int id, int manager_id, String occuation, String data, int fund) {
		super();
		this.id = id;
		this.manager_id = manager_id;
		this.occuation = occuation;
		this.data = data;
		this.fund = fund;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getManager_id() {
		return manager_id;
	}
	public void setManager_id(int manager_id) {
		this.manager_id = manager_id;
	}
	public String getOccuation() {
		return occuation;
	}
	public void setOccuation(String occuation) {
		this.occuation = occuation;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public int getFund() {
		return fund;
	}
	public void setFund(int fund) {
		this.fund = fund;
	}

	@Override
	public String toString() {
		return "Managerdefinedtb [id=" + id + ", manager_id=" + manager_id + ", occuation=" + occuation + ", data="
				+ data + ", fund=" + fund + "]";
	}
	
	

}
