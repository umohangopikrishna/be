package com.virtusa.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.project.models.UserInfotb;


public interface Repouserinfotb extends JpaRepository<UserInfotb,Integer> {

}
