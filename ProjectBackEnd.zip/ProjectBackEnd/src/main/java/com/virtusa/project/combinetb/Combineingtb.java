package com.virtusa.project.combinetb;

import com.virtusa.project.models.Usertb;

public class Combineingtb {

	private Usertb usertb_obj;
	
}
