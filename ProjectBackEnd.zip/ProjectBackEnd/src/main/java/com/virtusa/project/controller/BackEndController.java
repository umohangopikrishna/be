package com.virtusa.project.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.project.models.UserInfotb;
import com.virtusa.project.models.Usertb;
import com.virtusa.project.repository.Repouserinfotb;
import com.virtusa.project.repository.Repousetb;

@RestController
public class BackEndController {
    @Autowired
	private Repousetb repotb_obj;
    
    
    
    @PostMapping("/reguser")
    public boolean adduser(@RequestBody Usertb userobj)
    {  
    	try
    	{
    	repotb_obj.save(userobj);
    	return true;
    	}
      catch(Exception e)
    {
    	  return false;
    }
    
    }
    
    /*@GetMapping("/userauth")
    public boolean finduser(@PathVariable int flat_id , @PathVariable String password)
    {
    	
    	try
    	{
    		//Usertb userlist_obj = new ArrayList<Usertb>();
    		Usertb user_obj = new Usertb();
    	 	user_obj = repotb_obj.findById(flat_id).orElse(null);
    	   
    	 	if(user_obj == null)
    	 		return (false);
    	    return user_obj.getPassword().equals(password);
    	}
    	catch(Exception e)
    	{
    		return false;
    	}
    	
    }
    
    @DeleteMapping("/userdelet/{flat_id}")  // manager fun
    public boolean deletuser(@PathVariable int flat_id)
    {
    	
    	try
    	{
    		repotb_obj.deleteById(flat_id);
    		
    	    return true;
    	}catch(Exception e)
    	{
    		return false;
    	}
    }
    // forgin key
    @GetMapping("/paymode")
    public List<String> paymode_fun(@PathVariable String date)
    {   
 	   List<String> list_obj = new ArrayList<String>();
 	   
 	   List<Usertb> userpay_data = new ArrayList<Usertb>();
 	   userpay_data = repotb_obj.findAll();
 	   for(int i=0 ; i<userpay_data.size();i++)
 	   {
 		   
 		  List<UserInfotb> userinfolist = userpay_data.get(i).getUserdatalist();
 		  
 		  for(int j=0;j<userinfolist.size();j++)
 		  {
 			  boolean year_fg = userinfolist.get(j).getDatatopay().endsWith(date.substring(5, 10));
 		      boolean month_fg = userinfolist.get(j).getDatatopay().endsWith(date.substring(0, 2));
 		      
 		      if(year_fg && month_fg)
 		      {
 		    	  list_obj.add(userpay_data.get(i).getFlat_no()+","+userinfolist.get(j).getPaymode());
 		    	  break;
 		      }
 		  }
 	   }
 	  return(list_obj);
 	   }
    
    
    
     
 // gmail logic
    
	
//-----------------------------------------------------------------------------------------------

  */
    

@RequestMapping("/userauth")
public boolean finduser( String flat_id , String password)
    {
	
	List<Usertb> userlist = repotb_obj.findAll();
	
	for(int i=0;i<userlist.size();i++)
	{
		if(userlist.get(i).getFlat_no().equals(flat_id) && userlist.get(i).getPassword().equals(password))
			return true;
	}
	
	return false;
    	
    }

@DeleteMapping("/userdelet/{flat_id}")
public boolean deletuser(@PathVariable String flat_id)
{
	List<Usertb> userlist = repotb_obj.findAll();
    repotb_obj.deleteById(0);	
   /*
	try
	{
	 for(int i=0;i<userlist.size();i++)	
		{
		 
		if(userlist.get(i).getFlat_no().equals(flat_id))
	     {  
		    repotb_obj.deleteById(0);	
			return true;
		 }
	    }
	}
	catch(Exception e)
	{
		return false;
	}*/
	return false;
}



  
    
	
    
    
    
    
    
    
    
    
 
    
}

