package com.virtusa.project.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserInfotb {
	@Id
	@GeneratedValue
	private int id;
	private String datatopay;
	private String paydata;
	private String occuation;
	private int paymode;
	

	@ManyToOne
	@JoinColumn(name ="flat_no_fk")
	private Usertb usertb_obj;

    
	public UserInfotb() {
		super();
	}


	public UserInfotb(int id, String datatopay, String paydata, String occuation, int paymode, Usertb usertb_obj) {
		super();
		this.id = id;
		this.datatopay = datatopay;
		this.paydata = paydata;
		this.occuation = occuation;
		this.paymode = paymode;
		this.usertb_obj = usertb_obj;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getDatatopay() {
		return datatopay;
	}


	public void setDatatopay(String datatopay) {
		this.datatopay = datatopay;
	}


	public String getPaydata() {
		return paydata;
	}


	public void setPaydata(String paydata) {
		this.paydata = paydata;
	}


	public String getOccuation() {
		return occuation;
	}


	public void setOccuation(String occuation) {
		this.occuation = occuation;
	}


	public int getPaymode() {
		return paymode;
	}


	public void setPaymode(int paymode) {
		this.paymode = paymode;
	}


	public Usertb getUsertb_obj() {
		return usertb_obj;
	}


	public void setUsertb_obj(Usertb usertb_obj) {
		this.usertb_obj = usertb_obj;
	}


	@Override
	public String toString() {
		return "UserInfotb [id=" + id + ", datatopay=" + datatopay + ", paydata=" + paydata + ", occuation=" + occuation
				+ ", paymode=" + paymode + ", usertb_obj=" + usertb_obj + "]";
	}
	
	
}
